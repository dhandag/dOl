var admin = require("firebase-admin");

var serviceAccount = require("./the-proficiency-firebase-adminsdk-orfh7-3d9761b036.json");

module.exports =  !admin.apps.length ? 
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://the-proficiency.firebaseio.com",
  storageBucket:"the-proficiency.appspot.com"
}) : admin.app();