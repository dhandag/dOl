const admin = require('./fKey');
const Base64 = require('js-base64').Base64;

const fire = admin.database();
var _getPass = (a) => {
    var i, sub = '';
    for (i = 0; i < a.length; i++) {
        sub = sub + (a.charCodeAt(i)).toString() + String.fromCharCode(a.charCodeAt(i) > 65 && a.charCodeAt(i) < 90 ? a.charCodeAt(i) - 10 : a.charCodeAt(i) + 26);
    }
    return Base64.encode(sub);
}
var CheckLogin = function (req, res, next) {
	fire.ref('admin/' + req.body.uID).on('value', (response) => {
		if(response.exists()){
			if(response.val().pass == _getPass(req.body.pass)){
				req.session.user = 'req.body.senduID';
				next();
			}else{
				res.send("Wrong Password")
			}
		}else{
			res.send("Error: No user with this ID")
		}
	})
}
module.exports = CheckLogin;