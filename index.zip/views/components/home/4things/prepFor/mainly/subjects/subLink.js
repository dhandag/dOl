const firebase = require('../../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('prepration/' + req.params.prepFor + '/mainly/' + req.params.mainly + '/subjects/' + req.params.id).update({ active: true }).then(() => {
        fire.ref('prepration/' + req.params.prepFor + '/mainly/' + req.params.mainly + '/details').once('value', (response) => {
            res.locals.name = response.val().name;
        }).then(() => {
            var arrLSub = [];
            fire.ref('prepration/' + req.params.prepFor + '/mainly/' + req.params.mainly + '/subjects/').once('value', (resp) => {
                resp.forEach((child) => {
                    arrLSub.push(child.key)
                })
            }).then(() => {
                fire.ref('subjects/').once('value', (response) => {
                    var arr = [];
                    response.forEach((child) => {
                        if (child.key != 'free') {
                            arr.push({
                                id: child.key,
                                name: child.val().details.name,
                                dis: child.val().details.dis,
                                ul: arrLSub.indexOf(child.key) >= 0 ? 'Unlink' : 'Link'
                            })
                        }
                    })
                    res.locals.data = arr;
                    res.locals.success= 'Subject has been Linked!';
                    next();
                })
            })
        })
    })
}