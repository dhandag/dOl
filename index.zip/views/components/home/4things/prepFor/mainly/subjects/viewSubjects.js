const firebase = require('../../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('prepration/' + req.params.prepFor + '/mainly/' + req.params.mainly + '/details').once('value', (response) => {
        res.locals.name = response.val().name;
    })
    var arrS = [];
    fire.ref('prepration/' + req.params.prepFor + '/mainly/' + req.params.mainly + '/subjects/').once('value', (response) => {
        response.forEach((childS) => {
            arrS.push(childS.key)
        })
    }).then(() => {
        fire.ref('subjects').once('value',(response)=>{
            var arr=[];
            response.forEach((child)=>{
                if(arrS.indexOf(child.key)>=0){
                    arr.push({
                    id: child.key,
                    name: child.val().details.name,
                    dis: child.val().details.dis,
                })
            }
            })
            res.locals.data = arr;
            next();
        
        })
    })
}