const firebase = require('../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    if (req.body.name != '' && req.body.dis != '') {
        var tempID = 0;
        fire.ref('prepration/'+req.params.prepFor+'/mainly/free').once('value', (response) => {
            tempID = response.exists()?response.val():101;
        }).then(()=>{
            fire.ref('prepration/'+req.params.prepFor+'/mainly/'+req.params.prepFor+tempID+'/details').update({
                name: req.body.name,
                dis: req.body.dis
            }).then(()=>{
                fire.ref('prepration/'+req.params.prepFor+'/mainly').update({
                    free: parseInt(tempID,10)+1
                }).finally(()=>{
                    res.locals.success = 'Mainly is added Successfully.'
                    next();
                })
            })
        })
    } else {
        res.locals.error = 'Please check all the Details again.';
        next();
    }
}