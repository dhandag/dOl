const firebase = require('../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req,res,next)=>{
    fire.ref('boards/').once('value',(response)=>{
        var arr=[];
        response.forEach((child)=>{
        console.log(child.val())
            if(child.key!='free'){
                arr.push({
                id: child.key,
                name: child.val().details.name,
                dis: child.val().details.dis,
            })
        }
        })
        res.locals.data = arr;
        next();
    })
}