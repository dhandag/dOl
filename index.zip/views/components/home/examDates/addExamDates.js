const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    if (req.body.date != '' && req.body.time != '') {
        var tim = req.body.date.split("-");
        fire.ref("exams/dailyTime/"+tim[2]+tim[1]+tim[0]).update({
            time: req.body.time
        }).then(() => {
            res.locals.success = 'Subject is added Successfully.'
            next();
        })
    } else {
        res.locals.error = 'Please check all the Details again.';
        next();
    }
}