const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
        fire.ref("exams/dailyTime/"+req.params.date).once('value', (response) => {
            res.body = {
            date:response.key,
            time: response.val().time
        }
    }).then(() => {
        next();
    })
}