const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('exams/dailyTime/').once('value', (response) => {
        var arr = [];
        response.forEach((child) => {
            arr.push({
                date: child.key,
                time: child.val().time,
            })
        })
        res.locals.data = arr;
        next();
    })
}