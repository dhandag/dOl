const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    if (req.body.time != '' && req.body.date != '') {
        var date = req.params.date;
        fire.ref("exams/dailyTime/" + date).update({
            time: req.body.time
        }).then(() => {
            res.locals.success = 'Subject is Updated Successfully.'
            next();
        })
    } else {
        res.locals.error = 'Please check all the Details again.';
        next();
    }
}