const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('teachers/').once('value', (response) => {
        var arr = [];
        response.forEach((child) => {
            if (child.key != 'qBank') {
                arr.push({
                    tId: child.key,
                    name: child.val().details.name,
                    number: child.val().details.phone,
                    email: child.val().details.email,
                    s: child.val().details.state,
                    d: child.val().details.d,
                    age: child.val().details.age,
                    experience: child.val().details.experience,
                    gen: child.val().details.gen,
                })
            }
        })
        res.locals.data = arr;
        next();
    })
}