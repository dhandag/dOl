const firebase = require('../../../../config/fKey');
const fire = firebase.database();
const noV = /^\d{10}$/;
const emailV = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
const nameV = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
const _getPass = (a) => {
    var i, sub = '';
    for (i = 0; i < a.length; i++) {
        sub = sub + (a.charCodeAt(i)).toString() + String.fromCharCode(a.charCodeAt(i) > 65 && a.charCodeAt(i) < 90 ? a.charCodeAt(i) - 10 : a.charCodeAt(i) + 26);
    }
    return Base64.encode(sub);
}

module.exports = (req, res, next) => {
    if (!nameV.test(req.body.name)) {
        res.locals.error = "Name is invalid";
        next();
    }
    if (!emailV.test(req.body.email)) {
        res.locals.error = "Email is invalid";
        next();
    }
    if (req.body.s == undefined) {
        res.locals.error = "State is invalid";
        next();
    }
    if (req.body.d == '') {
        res.locals.error = "City is invalid";
        next();
    }

    fire.ref('teachers/' + req.params.tId + '/details').update({
        name: req.body.name,
        age: req.body.age,
        state: req.body.s,
        city: req.body.d,
        experience: req.body.experience,
        email: req.body.email,
        gen: req.body.gen
    }).then(() => {
        res.locals = { success: "Teacher has been Edited Successfully!" }
        next();
    })
}