const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('teachers/' + req.params.tId).once('value', (response) => {
        res.body = {
            tId: req.params.tId,
            name: response.val().details.name,
            number: response.val().details.phone,
            email: response.val().details.email,
            age: response.val().details.age,
            experience: response.val().details.experience,
            gen: response.val().details.gen,
            s: response.val().details.state,
            d: response.val().details.city,
        }
    }).then(() => {
        next();
    })
}