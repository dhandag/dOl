const firebase = require('../../../../config/fKey');
const fire = firebase.database();
const noV = /^\d{10}$/;
const emailV = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
const nameV = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
const _getPass = (a) => {
    var i, sub = '';
    for (i = 0; i < a.length; i++) {
        sub = sub + (a.charCodeAt(i)).toString() + String.fromCharCode(a.charCodeAt(i) > 65 && a.charCodeAt(i) < 90 ? a.charCodeAt(i) - 10 : a.charCodeAt(i) + 26);
    }
    return Base64.encode(sub);
}

module.exports = (req, res, next) => {
    if (!nameV.test(req.body.name)) {
        res.locals.error = "Name is invalid";
        next();
    }
    if (!noV.test(req.body.number)) {
        res.locals.error = 'Phone Number is Invalid';
        next();
    }
    if (!emailV.test(req.body.email)) {
        res.locals.error = "Email is invalid";
        next();
    }
    if (req.body.s == undefined) {
        res.locals.error = "State is invalid";
        next();
    }
    if (req.body.d == '') {
        res.locals.error = "City is invalid";
        next();
    }
    var tempID = 0;
    fire.ref('tIds/' + req.body.number).once('value', (response) => {
        if (response.exists()) {
            res.locals.error = "Phone Number Already exists";
            next();
        } else {
            fire.ref('tIds/free').once('value', (response) => {
                tempID = response.exists()?response.val():100001;
            }).then(() => {
                fire.ref('tIds/' + req.body.number).update({
                    createdOn: Date.now(),
                    id: "20" + tempID.toString(),
                    verify: Math.floor(100000 + Math.random() * 900000) + 1,
                    pass: _getPass(req.body.number + "@TP@" + req.body.age)
                }).then(() => {
                    fire.ref('teachers/20' + tempID + '/details').update({
                        name: req.body.name,
                        age: req.body.age,
                        state: req.body.s,
                        city: req.body.d,
                        experience: req.body.experience,
                        phone: req.body.number,
                        email: req.body.email,
                        gen: req.body.gen
                    }).then(() => {
                        fire.ref('tIds/').update({
                            free: tempID + 1,
                        }).finally(() => {
                            res.locals = { success: "Teacher has been added Successfully!", info: req.body.number + "@TP@" + req.body.age + " and 20" + tempID + " is the Password and ID for " + (req.body.gen == 'Male' ? "Mr. " : "Mrs. ") + req.body.name }
                            next();
                        })
                    })
                })
            })
        }
    })
}