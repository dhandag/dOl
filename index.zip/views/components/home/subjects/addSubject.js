const firebase = require('../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    if (req.body.name != '' && req.body.dis != '') {
        var tempID = 0;
        fire.ref('subjects/free').once('value', (response) => {
            tempID = response.exists()?response.val():1001;
        }).then(()=>{
            fire.ref('subjects/s'+tempID+'/details').update({
                name: req.body.name,
                dis: req.body.dis
            }).then(()=>{
                fire.ref('subjects/').update({
                    free: parseInt(tempID,10)+1
                }).finally(()=>{
                    res.locals.success = 'Subject is added Successfully.'
                    next();
                })
            })
        })
    } else {
        res.locals.error = 'Please check all the Details again.';
        next();
    }
}