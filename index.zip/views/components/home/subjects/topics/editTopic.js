const firebase = require('../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
        fire.ref('subjects/' +req.params.sub+'/topics/'+ req.params.id).once('value', (response) => {
        res.body = {
            id: req.params.id,
            name: response.val().details.name,
            dis: response.val().details.dis
        }
    }).then(() => {
        next();
    })
}