const firebase = require('../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('subjects/' + req.params.sub + '/details').once('value', (response) => {
        fire.ref('subjects/' + req.params.sub + '/topics/' + req.params.topic + '/details').once('value', (reso) => {
            res.locals.topicn = reso.val().name;
            res.locals.name = response.val().name;
            fire.ref('subjects/' + req.params.sub + '/topics/' + req.params.topic + "/questions").once('value', (response) => {
                var arrQI = [];
                var arr = [];
                response.forEach((child) => {
                    if (child.key != 'free') {
                        arrQI.push(child.key)
                    }
                })
                if (arrQI.length!=0) {
                    arrQI.map((item, index) => {
                        fire.ref('questions/' + item).once('value', (resp) => {
                            arr.push({
                                id: item,
                                approved: resp.val().details.approved,
                                by: resp.val().details.by,
                                isPic: resp.val().details.isPic,
                            })
                            if (index == (arrQI.length - 1)) {
                                res.locals.data = arr;
                                next();
                            }
                        })
                    })
                } else {
                    res.locals.data = arr;
                    next();
                }
            })

        })
    })
}