const firebase = require('../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    if (req.body.name != '' && req.body.dis != '') {
        fire.ref('subjects/' + req.params.sub + '/topics/' + req.params.id + '/details').update({
            name: req.body.name,
            dis: req.body.dis
        }).then(() => {
            res.locals.success = 'Topic is Updated Successfully.'
            next();
        })
    } else {
        res.locals.error = 'Please check all the Details again.';
        next();
    }
}