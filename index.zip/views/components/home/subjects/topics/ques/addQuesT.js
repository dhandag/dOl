const firebase = require('../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    fire.ref('teachers/').once('value', (response) => {
        var arrKey = [];
        var arrName = [];
        response.forEach(child => {
            if (child.key != 'qBank') {
                arrKey.push(child.key);
                arrName.push(child.val().details.name);
            }
        });
        res.locals.arrKey = arrKey;
        res.locals.arrName = arrName;
        next();
    })
}