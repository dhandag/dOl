const firebase = require('../../../../../../config/fKey');
const fire = firebase.database();
const multer = require('multer');
const UUID = require("uuid-v4");

module.exports = (req, res, next) => {
    var arrKey = [];
    var arrName = [];
    fire.ref('teachers/').once('value', (response) => {
        response.forEach(child => {
            if (child.key != 'qBank') {
                arrKey.push(child.key);
                arrName.push(child.val().details.name);
            }
        });
    }).then(() => {
        var tempID;
        fire.ref('questions/free').once('value', (response) => {
            tempID = response.exists() ? response.val() : 1000000001;
        }).then(() => {
            var fN = 0;
            const storage = multer.diskStorage({
                destination: 'ques/',
                filename: (req, file, cb) => {
                    fN += 1;
                    cb(null, tempID + '-' + (fN == 1 ? 'ques' : fN == 2 ? 'opt1' : fN == 3 ? 'opt2' : fN == 4 ? 'opt3' : 'opt4') + '.jpg');
                }
            })
            const checkFileType = (file, cb) => {
                // Allowed ext
                const filetypes = /jpeg|jpg|png|gif/;
                // Check ext
                const extname = filetypes.test(file.originalname.toLowerCase());
                // Check mime
                const mimetype = filetypes.test(file.mimetype);

                if (mimetype && extname) {
                    return cb(null, true);
                } else {
                    cb('Error: Images Only!');
                }
            }
            const upload = multer({
                storage: storage,
                limits: { fileSize: 1024 * 1024 },
                fileFilter: (req, file, cb) => {
                    checkFileType(file, cb)
                }
            }).array('quesP', 5);
            upload(req, res, (err) => {
                if (err) {
                    res.locals.arrKey = arrKey;
                    res.locals.arrName = arrName;
                    res.locals.error = 'Error Oucrred = ' + err;
                    next();
                } else {
                    if (req.files.length == 5 && req.body.optC != '' && req.body.teacher != '') {
                        const uuid = UUID();
                        if (firebase.storage().bucket().upload('ques/' + tempID + '-ques.jpg', {
                            destination: 'questions/' + tempID + '-ques',
                            metadata: {
                                metadata: {
                                    firebaseStorageDownloadTokens: uuid
                                }
                            }
                        })) {
                            if (firebase.storage().bucket().upload('ques/' + tempID + '-opt1.jpg', {
                                destination: 'questions/' + tempID + '-opt1',
                                metadata: {
                                    metadata: {
                                        firebaseStorageDownloadTokens: uuid
                                    }
                                }
                            })) {
                                if (firebase.storage().bucket().upload('ques/' + tempID + '-opt2.jpg', {
                                    destination: 'questions/' + tempID + '-opt2',
                                    metadata: {
                                        metadata: {
                                            firebaseStorageDownloadTokens: uuid
                                        }
                                    }
                                })) {
                                    if (firebase.storage().bucket().upload('ques/' + tempID + '-opt3.jpg', {
                                        destination: 'questions/' + tempID + '-opt3',
                                        metadata: {
                                            metadata: {
                                                firebaseStorageDownloadTokens: uuid
                                            }
                                        }
                                    })) {
                                        if (firebase.storage().bucket().upload('ques/' + tempID + '-opt4.jpg', {
                                            destination: 'questions/' + tempID + '-opt4',
                                            metadata: {
                                                metadata: {
                                                    firebaseStorageDownloadTokens: uuid
                                                }
                                            }
                                        })) {
                                            fire.ref('questions/q' + tempID + '/details').update({
                                                approved: false,
                                                optC: req.body.optC,
                                                by: req.body.teacher,
                                                isPic: true
                                            }).then(() => {
                                                fire.ref('questions/').update({
                                                    free: parseInt(tempID, 10) + 1
                                                }).then(() => {
                                                    fire.ref('subjects/' + req.params.sub + '/teachers/' + req.body.teacher + '/topics/' + req.params.topic + '/questions/q' + tempID).update({
                                                        by: req.body.teacher
                                                    })
                                                }).then(() => {
                                                    fire.ref('subjects/' + req.params.sub + '/topics/' + req.params.topic + '/questions/q' + tempID).update({
                                                        by: req.body.teacher
                                                    })
                                                }).then(() => {
                                                    fire.ref('teachers/' + req.body.teacher + '/questions/q' + tempID).update({
                                                        topic: req.params.topic
                                                    })
                                                }).finally(() => {
                                                    res.locals.success = 'Question is added Successfully.'
                                                    res.locals.arrKey = arrKey;
                                                    res.locals.arrName = arrName;
                                                    next();
                                                })
                                            })
                                        } else {
                                            res.locals.arrKey = arrKey;
                                            res.locals.arrName = arrName;
                                            res.locals.error = 'Cannot Upload Option 4';
                                            next();
                                        }
                                    } else {
                                        res.locals.arrKey = arrKey;
                                        res.locals.arrName = arrName;
                                        res.locals.error = 'Cannot Upload Option 3';
                                        next();
                                    }
                                } else {
                                    res.locals.arrKey = arrKey;
                                    res.locals.arrName = arrName;
                                    res.locals.error = 'Cannot Upload Option 2';
                                    next();
                                }
                            } else {
                                res.locals.arrKey = arrKey;
                                res.locals.arrName = arrName;
                                res.locals.error = 'Cannot Upload Option 1';
                                next();
                            }
                        } else {
                            res.locals.arrKey = arrKey;
                            res.locals.arrName = arrName;
                            res.locals.error = 'Cannot Upload Question';
                            next();
                        }
                    } else {
                        res.locals.arrKey = arrKey;
                        res.locals.arrName = arrName;
                        res.locals.error = 'Please check all the Details again.';
                        next();
                    }
                }
            })

        })
    })
}