const firebase = require('../../../../../../config/fKey');
const fire = firebase.database();

module.exports = (req, res, next) => {
    var arrKey = [];
    var arrName = [];
    fire.ref('teachers/').once('value', (response) => {
        response.forEach(child => {
            if (child.key != 'qBank') {
                arrKey.push(child.key);
                arrName.push(child.val().details.name);
            }
        });
    }).then(() => {
        console.log(JSON.stringify(req.body))
        if (req.body.ques != '' && req.body.opt1 != '' && req.body.opt2 != '' && req.body.opt3 != '' && req.body.opt4 != '' && req.body.optC != '' && req.body.teacher != '') {
            var tempID = 0;
            fire.ref('questions/free').once('value', (response) => {
                tempID = response.exists() ? response.val() : 1000000001;
            }).then(() => {
                if (req.body.picP == 'Pics') {
                    multer.single()
                } else {
                    fire.ref('questions/q' + tempID + '/details').update({
                        question: req.body.ques,
                        approved: req.body.teacher != 'qBank' ? false : true,
                        opt1: req.body.opt1,
                        opt2: req.body.opt2,
                        opt3: req.body.opt3,
                        opt4: req.body.opt4,
                        optC: req.body.optC,
                        by: req.body.teacher,
                        isPic: false
                    })
                }
            }).then(() => {
                fire.ref('questions/').update({
                    free: parseInt(tempID, 10) + 1
                }).then(() => {
                    fire.ref('subjects/' + req.params.sub + '/teachers/' + req.body.teacher + '/topics/' + req.params.topic + '/questions/q' + tempID).update({
                        by: req.body.teacher
                    })
                }).then(() => {
                    fire.ref('subjects/' + req.params.sub + '/topics/' + req.params.topic + '/questions/q' + tempID).update({
                        by: req.body.teacher
                    })
                }).then(() => {
                    fire.ref('teachers/' + req.body.teacher + '/questions/q' + tempID).update({
                        topic: req.params.topic
                    })
                }).finally(() => {
                    res.locals.success = 'Question is added Successfully.'
                    res.locals.arrKey = arrKey;
                    res.locals.arrName = arrName;
                    next();
                })
            })
        } else {
            res.locals.arrKey = arrKey;
            res.locals.arrName = arrName;
            res.locals.error = 'Please check all the Details again.';
            next();
        }
    })
}