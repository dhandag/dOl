const session = require('express-session');
const CheckLogin = require('../config/checkLogin.js');


const addTeacher = require('./components/home/teachers/addTeacher');
const viewTeachers = require('./components/home/teachers/viewTeachers');
const editTeacher = require('./components/home/teachers/editTeacher');
const editPostTeacher = require('./components/home/teachers/editPostTeacher');

const addBUI = require('./components/home/4things/bui/addBUI');
const viewBUI = require('./components/home/4things/bui/viewBUI');
const editBUI = require('./components/home/4things/bui/editBUI');
const editPostBUI = require('./components/home/4things/bui/editPostBUI');

const addHDegree = require('./components/home/4things/hDegree/addHDegree');
const viewHDegree = require('./components/home/4things/hDegree/viewHDegree');
const editHDegree = require('./components/home/4things/hDegree/editHDegree');
const editPostHDegree = require('./components/home/4things/hDegree/editPostHDegree');

const addPrepFor = require('./components/home/4things/prepFor/addPrepFor');
const viewPrepFor = require('./components/home/4things/prepFor/viewPrepFor');
const editPrepFor = require('./components/home/4things/prepFor/editPrepFor');
const editPostPrepFor = require('./components/home/4things/prepFor/editPostPrepFor');

const addMainly = require('./components/home/4things/prepFor/mainly/addMainly');
const viewMainly = require('./components/home/4things/prepFor/mainly/viewMainly');
const editMainly = require('./components/home/4things/prepFor/mainly/editMainly');
const editPostMainly = require('./components/home/4things/prepFor/mainly/editPostMainly');

const viewSubjectMainly = require('./components/home/4things/prepFor/mainly/subjects/viewSubjects');
const linkSubjects = require('./components/home/4things/prepFor/mainly/subjects/linkSubjects');
const subLink = require('./components/home/4things/prepFor/mainly/subjects/subLink');
const subUnlink = require('./components/home/4things/prepFor/mainly/subjects/subUnlink');

const addSubject = require('./components/home/subjects/addSubject');
const viewSubjects = require('./components/home/subjects/viewSubjects');
const editSubject = require('./components/home/subjects/editSubject');
const editPostSubject = require('./components/home/subjects/editPostSubject');

const addTopic = require('./components/home/subjects/topics/addTopic');
const viewTopics = require('./components/home/subjects/topics/viewTopics');
const editTopic = require('./components/home/subjects/topics/editTopic');
const editPostTopic = require('./components/home/subjects/topics/editPostTopic');

const addQues = require('./components/home/subjects/topics/ques/addQues');
const addQuesT = require('./components/home/subjects/topics/ques/addQuesT');
const addQuesP = require('./components/home/subjects/topics/ques/addQuesP');
const viewQues = require('./components/home/subjects/topics/ques/viewQues');
const editQues = require('./components/home/subjects/topics/ques/editQues');
const editPostQues = require('./components/home/subjects/topics/ques/editPostQues');


const addExamDates = require('./components/home/examDates/addExamDates');
const viewExamDates = require('./components/home/examDates/viewExamDates');
const editExamDates = require('./components/home/examDates/editExamDates');
const editPostExamDates = require('./components/home/examDates/editPostExamDates');



module.exports = (app) => {
    var isLogin = (user) => {
        if (user) {
            return true
        } else {
            return false
        }
    }
    // required for passport
    app.use(session({
        secret: 'DHANDAg',
        resave: true,
        saveUninitialized: true
    }))

    // login
    app.get('/', (req, res) => {
        if (!isLogin(req.session.user)) {
            res.render('./auth/index', { title: 'The Proficiency' });
        } else {
            res.redirect('home')
        }
    })
    app.post('/', CheckLogin, (req, res) => {
        res.redirect('/home');
    })
    app.get('/logout', (req, res) => {
        req.session.destroy(() => {
            res.redirect('/');
        })
    })

    // dashBoard
    app.get('/home', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/dash');
        } else {
            res.redirect('/');
        }
    })


    // Teachers
    app.get('/addTeacher', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/teachers/addTeacher', { error: '', success: '', info: '', body: req.body });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addTeacher', addTeacher, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/teachers/addTeacher', { error: res.locals.error, success: res.locals.success, info: res.locals.info, body: res.locals.success ? '' : req.body });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewTeachers', viewTeachers, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/teachers/viewTeachers', { data: res.locals.data });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editTeacher/:tId', editTeacher, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/teachers/editTeacher', { error: '', success: '', info: '', body: res.body, tId: req.params.tId });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editTeacher/:tId', editPostTeacher, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/teachers/editTeacher', { error: res.locals.error, success: res.locals.success, body: req.body, tId: req.params.tId });
        } else {
            res.redirect('/')
        }
    })

    //----4 Things----

    //BUI
    app.get('/addBUI', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/bui/addBUI', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' } });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addBUI', addBUI, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/bui/addBUI', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewBUI', viewBUI, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/bui/viewBUI', { data: res.locals.data });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editBUI/:id', editBUI, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/bui/editBUI', { error: '', success: '', info: '', body: res.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editBUI/:id', editPostBUI, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/bui/editBUI', { error: res.locals.error, success: res.locals.success, body: req.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })

    //HDegree
    app.get('/addHDegree', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/hDegree/addHDegree', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' } });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addHDegree', addHDegree, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/hDegree/addHDegree', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewHDegree', viewHDegree, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/hDegree/viewHDegree', { data: res.locals.data });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editHDegree/:id', editHDegree, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/hDegree/editHDegree', { error: '', success: '', info: '', body: res.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editHDegree/:id', editPostHDegree, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/hDegree/editHDegree', { error: res.locals.error, success: res.locals.success, body: req.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })

    //PrepFor
    app.get('/addPrepFor', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/addPrepFor', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' } });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addPrepFor', addPrepFor, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/addPrepFor', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewPrepFor', viewPrepFor, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/viewPrepFor', { data: res.locals.data });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editPrepFor/:id', editPrepFor, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/editPrepFor', { error: '', success: '', info: '', body: res.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editPrepFor/:id', editPostPrepFor, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/editPrepFor', { error: res.locals.error, success: res.locals.success, body: req.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })

    //Mainly
    app.get('/addMainly/:prepFor', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/addMainly', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' }, prepFor: req.params.prepFor });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addMainly/:prepFor', addMainly, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/addMainly', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body, prepFor: req.params.prepFor });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewMainly/:prepFor', viewMainly, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/viewMainly', { data: res.locals.data, name: res.locals.prepForName, prepFor: req.params.prepFor });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editMainly/:prepFor-:mainly', editMainly, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/editMainly', { error: '', success: '', info: '', body: res.body, mainly: req.params.mainly });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editMainly/:prepFor-:mainly', editPostMainly, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/editMainly', { error: res.locals.error, success: res.locals.success, body: req.body, mainly: req.params.mainly });
        } else {
            res.redirect('/')
        }
    })

    // Linking Subjects
    app.get('/:prepFor/:mainly/viewSubjects', viewSubjectMainly, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/subjects/viewSubjects', { data: res.locals.data, prepFor: req.params.prepFor, mainly: req.params.mainly, name: res.locals.name });
        } else {
            res.redirect('/')
        }
    })
    app.get('/:prepFor/:mainly/linkSubjects', linkSubjects, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/subjects/linkSubjects', { success: '', data: res.locals.data, prepFor: req.params.prepFor, mainly: req.params.mainly, name: res.locals.name });
        } else {
            res.redirect('/')
        }
    })
    app.get('/:prepFor/:mainly/subLink/:id', subLink, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/subjects/linkSubjects', { success: res.locals.success, data: res.locals.data, prepFor: req.params.prepFor, mainly: req.params.mainly, name: res.locals.name });
        } else {
            res.redirect('/')
        }
    })
    app.get('/:prepFor/:mainly/subUnlink/:id', subUnlink, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/4things/prepFor/mainly/subjects/linkSubjects', { success: res.locals.success, data: res.locals.data, prepFor: req.params.prepFor, mainly: req.params.mainly, name: res.locals.name });
        } else {
            res.redirect('/')
        }
    })

    //Subject
    app.get('/addSubject', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/addSubject', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' } });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addSubject', addSubject, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/addSubject', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewSubjects', viewSubjects, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/viewSubjects', { data: res.locals.data });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editSubject/:id', editSubject, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/editSubject', { error: '', success: '', info: '', body: res.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editSubject/:id', editPostSubject, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/editSubject', { error: res.locals.error, success: res.locals.success, body: req.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })

    //Topic
    app.get('/addTopic/:sub', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/addTopic', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' }, sub: req.params.sub });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addTopic/:sub', addTopic, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/addTopic', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body, sub: req.params.sub });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewTopics/:sub', viewTopics, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/viewTopics', { data: res.locals.data, sub: req.params.sub, name: res.locals.name });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editTopic/:sub-:id', editTopic, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/editTopic', { error: '', success: '', info: '', body: res.body, sub: req.params.sub, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editTopic/:sub-:id', editPostTopic, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/editTopic', { error: res.locals.error, success: res.locals.success, body: req.body, sub: req.params.sub, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })

    //Ques
    app.get('/addQues/:sub-:topic', addQuesT, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/ques/addQues', { error: '', success: '', info: '', body: res.body ? res.body : { ques: '', opt1: '', opt2: '', opt3: '', opt4: '', }, sub: req.params.sub, topic: req.params.topic, arrKey: res.locals.arrKey, arrName: res.locals.arrName });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addQues/:sub-:topic', addQues, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/ques/addQues', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? { ques: '', opt1: '', opt2: '', opt3: '', opt4: '', } : req.body, sub: req.params.sub, topic: req.params.topic, arrKey: res.locals.arrKey, arrName: res.locals.arrName });
        } else {
            res.redirect('/')
        }
    })
    app.get('/addQuesP/:sub-:topic', (req, res) => {
        res.redirect('/addQues/' + req.params.sub + '-' + req.params.topic);
    })
    app.post('/addQuesP/:sub-:topic', addQuesP, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/ques/addQues', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? { ques: '', opt1: '', opt2: '', opt3: '', opt4: '', } : req.body, sub: req.params.sub, topic: req.params.topic, arrKey: res.locals.arrKey, arrName: res.locals.arrName });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewQues/:sub-:topic', viewQues, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/ques/viewQues', { data: res.locals.data, sub: req.params.sub, topicN: 'req.locals.topicn', name: res.locals.name, topic: req.params.topic });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editQues/:sub-:id', editQues, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/ques/editQues', { error: '', success: '', info: '', body: res.body, sub: req.params.sub, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editQues/:sub-:id', editPostQues, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/subjects/topics/ques/editQues', { error: res.locals.error, success: res.locals.success, body: req.body, sub: req.params.sub, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })




    // Exam Date
    app.get('/addExamDates', (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/examDates/addExamDates', { error: '', success: '', info: '', body: res.body ? res.body : { name: '', dis: '' } });
        } else {
            res.redirect('/')
        }
    })
    app.post('/addExamDates', addExamDates, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/examDates/addExamDates', { error: res.locals.error, success: res.locals.success, body: res.locals.success ? '' : req.body });
        } else {
            res.redirect('/')
        }
    })
    app.get('/viewExamDates', viewExamDates, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/examDates/viewExamDates', { data: res.locals.data });
        } else {
            res.redirect('/')
        }
    })
    app.get('/editExamDates/:date', editExamDates, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/examDates/editExamDates', { error: '', success: '', info: '', body: res.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })
    app.post('/editExamDates/:date', editPostExamDates, (req, res) => {
        if (isLogin(req.session.user)) {
            res.render('./home/examDates/editExamDates', { error: res.locals.error, success: res.locals.success, body: req.body, id: req.params.id });
        } else {
            res.redirect('/')
        }
    })




}