const express = require('express');
const path = require('path');
// const session = require('express-session');
const bodyParser = require('body-parser');
const port = process.env.PORT || 3000;
const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}));
require('./views/routes')(app);


app.use((req, res, next) => {
    var err = new Error('Page not Found');
    err.status = 404;
    next(err);
})
app.use((err, req, res, next) => {
    res.status(err.status || 501);
    res.send("Error Ouccering " + err.message);
})


app.listen(port, () => {
    console.log('Started')
})