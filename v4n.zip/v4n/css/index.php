<?php
header('Location: ../');
?>