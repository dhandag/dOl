<?php
$rand=rand(1,2);
?>
<html>
	<head>
		<title>LOGIN</title>
		<SCRIPT LANGUAGE="JavaScript" SRC="js/Forml.js">
		</script>
		<link rel="stylesheet" href="css/style.css">

	</head>
	<body bgcolor=#f2fff5>
		<table class=tab_head align=right>

			<td class=logo>
				<a href=index.php><img src=images/logo<?php echo $rand;?>.png class=logo ></a>
			</td>
			<td class=find>	
				<input type=text placeholder=Search...><input type=submit value="GO!">
			</td>
			<td align=right class=login>
				<a href="login.php">Login or Register</a>
			</td>
			<td align=right>
				<div id=ul_menu>
					<ul>
						<li>	
							<a href=#>Menu</a> 
								<ul>
									<li><a href=home.php>Home</a></li>
									<li><a href=#>About</a></li>
									<li><a href=#>Videos</a></li>
									<li><a href=#>Contact</a></li>
								</ul>
						</li>
					</ul>
				</div>
			</td>
		</table>
	
		
	<?php
		$msg="";
		$conn= mysqli_connect("localhost","root","","nation4voice") or die("Server Error");
		if(isset($_POST['lsubmit'])){
			$uname= $_POST['uname'];
			$pass= $_POST['pass'];
			$pass_len=strlen($pass);
			if(empty($uname) or empty($pass) or $pass_len<=8)
				{
					$msg= "All fields are Modtary.";
				}
			
			
			
			$query = mysqli_query($conn, "select * from registration where uname='$uname'");
			
			
			if(mysqli_num_rows($query)== 1){
				if($row=mysqli_fetch_array($query)){
					if(password_verify($pass,$row['pass'])){
						if($rm=="on"){
							setcookie("uname",$uname,time()+(864000));
						}else{
							session_start();
							$_SESSION['uname']=$uname;
						}
						$msg ="LOGIN Sucessful";
						header("Location: Home.php");
					}
				}
			}
		}$msg ="Invaid User_Name or Password";
?>
		<form class=form action=""	name=form method=post onsubmit="lclicked()">
			<font color=red><?php echo $msg;?></font><br>
			Username:<input type=text name=uname placeholder="Please Enter Your UserName"><br>
			Password:<input type=password name=pass placeholder="Please Enter Your pass"><br>
			<input type=checkbox name=rm value="on" > REMBER ME FOR 10 DAYS
			<input type=submit name=lsubmit value="Go!" ><br>
			
		</form>
		
		
		
		
		
		
		
		
		
		
		
		
		
	</body>
</html>
