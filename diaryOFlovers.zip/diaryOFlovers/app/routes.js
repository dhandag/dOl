var dbconfig = require('../config/database');
var mysql = require('mysql');
var connection = mysql.createConnection(dbconfig.connection); 
var bcrypt = require('bcrypt-nodejs');
connection.query('USE ' + dbconfig.database);


module.exports = function(app,passport) {

    app.get('/',(req,res)=>{
		if(req.isAuthenticated())
			res.render('profile');
		else
			res.render('index.ejs');
	});

	
    app.get('/login', loggedin,function(req, res) {
if(!req.user)
        res.render('signup.ejs',{ message: req.flash('loginMessage') });
	else
		res.render('/');

    });
	app.get('/profile',isLoggedIn,step,(req,res)=>{
		res.render('profile.ejs');
	});
	
	
    app.get('/signup',loggedin, function(req, res){
        res.render('signup.ejs',{message: req.flash('signupMessage')});
      });
	  
	app.get('/signupI',isLoggedIn, (req,res)=>{
		res.render('signupI.ejs');
	});

    app.post('/signup', passport.authenticate('local-signup', {
            successRedirect: '/profile',
            failureRedirect: '/signup',
            failureFlash : true 
    }));

    app.post('/login', passport.authenticate('local-login', {
            successRedirect : '/profile', 
            failureRedirect : '/login',
            failureFlash : true 
        }),
        function(req, res) {
            console.log("hello");

            if (req.body.remember) {
              req.session.cookie.maxAge = 1000 * 60 * 3;
            } else {
              req.session.cookie.expires = false;
            }
        res.redirect('/');
    });
    app.get('/logout', function(req, res) {
        req.logout();
        res.redirect('/');
    });


};

function step(req,res,next){
	var rows = [];
	connection.query("SELECT * FROM contact WHERE username = ?",[req.user.username], function(err, rows) {
			console.log(rows);
			if(rows.length)
				if (req.url='/signupI')
					res.redirect('/profile');
				else return next();
});
}
function isLoggedIn(req,res,next){
	if(req.isAuthenticated())
		return next();
	res.redirect('/');
}

function loggedin (req,res,next){
	if(!req.isAuthenticated())
		return next();
	res.redirect('/profile');
}