<?php
$rand=rand(1,2);
?>
<html>
	<head>
		<title>REGISTER</title>	
		<SCRIPT LANGUAGE="JavaScript" SRC="js/Formr.js">
		</script>
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body bgcolor=#f2fff5>
		<table class=tab_head align=right>

			<td class=logo>
				<a href=index.php><img src=images/logo<?php echo $rand;?>.png class=logo ></a>
			</td>
			<td class=find>	
				<input type=text placeholder=Search...><input type=submit value="GO!">
			</td>
			<td align=right class=login>
				<a href="registration.php">Login or Register</a>
			</td>
			<td align=right>
				<div id=ul_menu>
					<ul>
						<li>	
							<a href=#>Menu</a>
								<ul>
									<li><a href=home.php>Home</a></li>
									<li><a href=#>About</a></li>
									<li><a href=#>Videos</a></li>
									<li><a href=#>Contact</a></li>
								</ul>
						</li>
					</ul>
				</div>
			</td>
		</table>

		
		<?php
		$msg="";
		$conn= mysqli_connect("localhost","root","","nation4voice") or die("Server Error");
		if(isset($_POST['lsubmit'])){
			$uname= $_POST['uname'];
			$pass= $_POST['pass'];
			$pass_len=strlen($pass);
			if(empty($uname) or empty($pass) or $pass_len<=8)
				{
					$msg= "All fields are Modtary.";
				}
			
			
			
			$query = mysqli_query($conn, "select * from registration where uname='$uname'");
			$result=mysqli_num_rows($query);
			
			if($result==1){
				if($row=mysqli_fetch_array($query)){
					if(password_verify($pass,$row['pass'])){
						if($rm=="on"){
							setcookie("uname",$uname,time()+(864000));
						}else{
							session_start();
							$_SESSION['uname']=$uname;
						}
						$msg ="LOGIN Sucessful";
						header("Location: Home.php");	
						}$msg ="Invaid User_Name or Password";
					}
				}
		}
?>
	
	<table align=center>
	<td>
		<form class=lform action=""	name=form method=post onsubmit="lclicked()">
			<font color=red><?php echo $msg;?></font><br>
			Username:<input type=text name=uname placeholder="Please Enter Your UserName"><br>
			Password:<input type=password name=pass placeholder="Please Enter Your pass"><br>
			<input type=checkbox name=rm value="on" > REMBER ME FOR 10 DAYS
			<input type=submit name=lsubmit value="Go!" ><br>
			
		</form>
		
		</td>
		
		

		<td>
			<div id=or>
				OR
			</div>
		</td>
		<td>
		<form class=rform action=""	name=form method=post onsubmit="clicked()" enctype="multipart/form-data">
			Fullname:<input type=text name=fname placeholder="Please Enter Your Full Name."><br>
			Username:<input type=text name=uname placeholder="Please Enter Your UserName"><br>
			Email:<input type=text name=email placeholder="Please Enter Your Valid Email Address"><br>
			Phone No.:<input type=number name=phone placeholder="Please Enter Your Valid Phone No."><br>
			Password:<input type=password name=pass placeholder="Please Enter Your pass"><br>
			<input type=submit name=submit value="Go!" >
		</form>
		</td>
		
		
		
		<?php
$conn = mysqli_connect("localhost","root","",'nation4voice') or die('Please Check your USERNAME and pass');
if(isset($_POST['submit'])){
	$fname=$_POST['fname'];
	$uname=$_POST['uname'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$pass=$_POST['pass'];
	$pass_len=strlen($pass);
	$phone_len=strlen($phone);
	$pass = password_hash($pass, PASSWORD_DEFAULT);
	$image="default_img.jpg";
	$check_email= mysqli_query($conn,"SELECT * FROM REGISTRATION WHERE EMAIL='$email'");
	$check_phone= mysqli_query($conn,"SELECT * FROM REGISTRATION WHERE PHONE='$phone'");
	if(empty($fname)){
		$msg = "Please Enter Your FullName";
	}else if(empty($uname)){
		$msg = "Please Enter Your UserName";
	}else if(empty($email)){
		$msg = "Please Enter Your Valid Email Address";
	}else if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
		$msg = "Please Enter Your Valid Email Address";
	}else if($phone_len!=10){
		$msg = "Please Enter Your Valid Phone No.";
	}else if(empty($pass)){
		$msg = "Please Enter Your pass";
	}else if($pass_len<=8){
		$msg = "Please Enter more than 8 Digit long pass";
	}else if(mysqli_num_rows($check_email)==1){
		$msg = "This EMAIL is already Exist";
	}else if(mysqli_num_rows($check_phone)==1){
		$msg = "This PHONE NO. is already Exist";
	}else{
		$done = mysqli_query($conn,"insert into registration(fname, uname, email, phone, pass,image) VALUES('$fname', '$uname', '$email', '$phone','$pass','$image') ");
		if($done){
			header("Location: home.php");
		}else{
			echo"pro"; 
		}
	}
}

?>
	</body>
</html>