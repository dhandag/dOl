<?php
session_start();
session_destroy();
setcookie("uname","",time()-(864000));
header("Location: login.php");
exit();


?>