<?php
// the message
$msg = "First line of text\n\<a href \= dhandag.tech\>Second\<a\> line of text";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail("jaatdeepam@gmail.com","My subject",$msg,"DHANDAg<dhandag@info.tech>");
?>