var er1 =1; er2 =1; er3 =1, er4 =1; er5=1; er6=1; er7=1; er8=1; er9=1; er10=1; er11=1; er12=1; er13 =1; er14=1; er15=1; er16=1; er17=1; er18=1; er19=1; er20=1;
function fn(){
	var f=document.ist.fname.value;
	var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/
	if(!f.match(alpha)){
		document.ist.fname.focus();
							document.ist.fname.style.background="#9671c687";
							document.ist.fname.style.color="white";
							er1=1;

						}else{
						document.ist.fname.style.background="#9c9c9c00";
						document.ist.fname.style.color="#555"; 
						er1=0;
						// 	ar ids= document.getElementById("next_page_button");	
	}
}
function dmy(){
	
	var d=document.ist.day.value;
	var m=document.ist.month.value;
	var y=document.ist.year.value;
	if(d==""){
		document.ist.day.focus();
		document.ist.day.style.background="#9671c687";
		document.ist.day.style.color="white";
							er2=1;
	}else if(m==""){
		document.ist.month.focus();
		document.ist.month.style.background="#9671c687";
		document.ist.month.style.color="white";
							er2=1;
	}else if(y==""){
		document.ist.year.focus();
		document.ist.year.style.background="#9671c687";
		document.ist.year.style.color="white";    er2=1;
	}else{
		document.ist.day.style.background="#9c9c9c00";
		document.ist.day.style.color="#555";
		document.ist.month.style.background="#9c9c9c00";
		document.ist.month.style.color="#555";
		document.ist.year.style.background="#9c9c9c00";
		document.ist.year.style.color="#555";    er2=0;
	}
	fn(); er();
}
function maile(){
		
		var e= document.ist.email.value; 
			var atposition=e.indexOf("@");  
			var dotposition=e.lastIndexOf("."); 						
			if (atposition<1 || dotposition<atposition+2 || dotposition+2>=e.length){  
				//alert("Please enter a valid e-mail address!");  
				document.ist.email.focus();
				document.ist.email.style.background="#9671c687";
				document.ist.email.style.color="white";    er3=1;
			}else{
				document.ist.email.style.background="#9c9c9c00";
				document.ist.email.style.color="#555";    er3=0;
			}
			dmy(); er();
}
function cona(){
		
		var c= document.ist.contact.value;
		if (isNaN(c)|| c.length<1|| c.length !=10){
			//alert("Please enter a Valid Contact No.");
			document.ist.contact.focus();
			document.ist.contact.style.background="#9671c687";
			document.ist.contact.style.color="white";    er4=1;
			}else{
			document.ist.contact.style.background="#9c9c9c00";
			document.ist.contact.style.color="#555";    er4=0;
			}
			maile(); er();
}
function fa(){
	
	var f=document.nd.fathername.value;
	var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
					if(!f.match(alpha)){
							document.nd.fathername.focus();
							document.nd.fathername.style.background="#9671c687";
							document.nd.fathername.style.color="white";    er5=1;
						}else{
						document.nd.fathername.style.background="#9c9c9c00";
						document.nd.fathername.style.color="#555";    er5=0;
						
	} 
	cona(); er();
}
function m(){
	
	var f=document.nd.mothername.value;
	var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!f.match(alpha)){
		document.nd.mothername.focus();
							document.nd.mothername.style.background="#9671c687";
							document.nd.mothername.style.color="white";    er6=1;
						}else{
						document.nd.mothername.style.background="#9c9c9c00";
						document.nd.mothername.style.color="#555";    er6=0;
						
	}
	fa(); er();
}
function se(){
	
	var s= document.nd.s.value;
	if(s==""){
		document.nd.s.focus();
		document.nd.s.style.background="#9671c687";
		document.nd.s.style.color="white";    er7=1;
	}else{
		document.nd.s.style.background="#9c9c9c00";
		document.nd.s.style.color="#555";    er7=0;
		}
		m(); er();
}
function add(){
	
	var a= document.nd.add1.value;
	var b= document.nd.add2.value;
	if(a==""){
		document.nd.add1.focus();
		document.nd.add1.style.background="#9671c687";
		document.nd.add1.style.color="white";    er8=1;
	}else if(b==""){
		document.nd.add2.focus();
		document.nd.add2.style.background="#9671c687";
		document.nd.add2.style.color="white";    er8=1;
	}else{
		document.nd.add1.style.background="#9c9c9c00";
		document.nd.add1.style.color="#555";
		document.nd.add2.style.background="#9c9c9c00";
		document.nd.add2.style.color="#555";    er8=0;
	}
	se(); er();
}
function pinc(){
	
	var p= document.nd.pin.value;
		if(isNaN(p)||  p.length<1|| p.length !=6){
		//alert("Please enter a Valid Pin Code");
			document.nd.pin.focus();
			document.nd.pin.style.background="#9671c687";
			document.nd.pin.style.color="white";    er9=1;
		}else{
			document.nd.pin.style.background="#9c9c9c00";
			document.nd.pin.style.color="#555";    er9=0;
			}
			add();
			if(er1==0&&er2==0&&er3==0&&er4==0&&er5==0&&er6==0&&er7==0&&er8==0&&er9==0){
				alert("Next");
			}else{
				alert("err");
			}
			
}


function yel(){
	var el= document.forth.el.value;
	if(el==""){
		
		document.forth.el.focus();
		document.forth.el.style.background="#9671c687";
		document.forth.el.style.color="white";    er10=1;
	}else{
		document.forth.el.style.background="#9c9c9c00";
		document.forth.el.style.color="#555";    er10=0;
		}
		pinc(); er();
}

function yef(){
	var ef= document.forth.ef.value;
	if(ef==""){
		document.forth.ef.focus();
		document.forth.ef.style.background="#9671c687";
		document.forth.ef.style.color="white";    er11=1;
	}else{
		alert("fhaskjh");
		document.forth.ef.style.background="#9c9c9c00";
		document.forth.ef.style.color="#555";    er11=0;
		}
		yel(); er();
}

function pclg(){
	var clg=document.forth.clg.value;
	var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!clg.match(alpha)){
		document.forth.clg.focus();
		document.forth.clg.style.background="#9671c687";
		document.forth.clg.style.color="white";    er12=1;
		}else{
		document.forth.clg.style.background="#9c9c9c00";
		document.forth.clg.style.color="#555";    er12=0;
						
	}
	yef(); er();
}

function ywl(){
	var wl= document.forth.wl.value;
	if(wl==""){
		document.forth.wl.focus();
		document.forth.wl.style.background="#9671c687";
		document.forth.wl.style.color="white";    er13=1;
	}else{
		document.forth.wl.style.background="#9c9c9c00";
		document.forth.wl.style.color="#555";    er13=0;
		}
		pclg(); er();
}



function cwi(){
	var wi=document.forth.wi.value;
	var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!wi.match(alpha)){
		document.forth.wi.focus();
		document.forth.wi.style.background="#9671c687";
		document.forth.wi.style.color="white";    er14=1;
		}else{
		document.forth.wi.style.background="#9c9c9c00";
		document.forth.wi.style.color="#555";    er14=0;
						
	}
	ywl(); er();
}


function cwa(){
	var wa=document.forth.wa.value;
	var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!wa.match(alpha)){
		document.forth.wa.focus();
		document.forth.wa.style.background="#9671c687";
		document.forth.wa.style.color="white";    er15=1;
		}else{
		document.forth.wa.style.background="#9c9c9c00";
		document.forth.wa.style.color="#555";    er15=0;
						
	}
	cwi(); er();
}



function aincome(){
	var income= document.forth.income.value;
	if(income==""){
		document.forth.income.focus();
		document.forth.income.style.background="#9671c687";
		document.forth.income.style.color="white";    er16=1;
	}else{
		document.forth.income.style.background="#9c9c9c00";
		document.forth.income.style.color="#555";    er16=0;
		}
		cwa(); er();
}

function yreligion(){
	var religion= document.rd.religion.value;
	if(religion==""){
		document.rd.religion.focus();
		document.rd.religion.style.background="#9671c687";
		document.rd.religion.style.color="white";    er17=1;
	}else{
		document.rd.religion.style.background="#9c9c9c00";
		document.rd.religion.style.color="#555";    er17=0;
		}
		aincome(); er();
}

function yheight(){
	var height= document.rd.height.value;
	if(height==""){
		document.rd.height.focus();
		document.rd.height.style.background="#9671c687";
		document.rd.height.style.color="white";    er18=1;
	}else{
		document.rd.height.style.background="#9c9c9c00";
		document.rd.height.style.color="#555";    er18=0;
		}
		yreligion(); er();
}
function yms(){
	var ms= document.rd.ms.value;
	if(ms==""){
		document.rd.ms.focus();
		document.rd.ms.style.background="#9671c687";
		document.rd.ms.style.color="white";    er19=1;
	}else{
		document.rd.ms.style.background="#9c9c9c00";
		document.rd.ms.style.color="#555";    er19=0;
		}
		yheight(); er();
}


function dys(){
	var selfd = document.rd.selfd.value;
	if(selfd.length<25){
		document.rd.selfd.focus();
		document.rd.selfd.style.background="#9671c687";
		document.rd.selfd.style.color="white";    er20=1;
	}else{
		document.rd.selfd.style.background="#9c9c9c00";
		document.rd.selfd.style.color="#555";    er20=0;
		}
		yms(); er();
}
function er02(){
	if(er11==0&&er12==0&&er13==0&&er14==0&&er15==0&&er16==0&&er17==0&&er18==0&&er19==0&&er10==0&&er20==0) return er=0;
	else return 1;
}
