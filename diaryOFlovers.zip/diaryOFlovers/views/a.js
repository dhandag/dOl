var socket = io.connect('http://localhost:3000');

var message= document.getElementById("msg");
var handle= document.getElementById("handle");
var send= document.getElementById("send");
var output= document.getElementById("output");


send.addEventListener('click',function(){
    socket.emit('chat',{
        message: message.value,
        handle: handle.value
    });
});


message.addEventListener('keypress',function(){
    socket.emit('typing',message.value)
});

socket.on('chat',function(data){

    output.innerHTML +="<p>"+data.handle+'</p>';
    output1.innerHTML ="";
});
socket.on('typing',function(data){
    output1.innerHTML +="<p>"+data+' is typing</p>';
});