var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'dhandag.tech',
  auth: {
    user: 'admin@dhandag.tech',
    pass: '80531@ddj'
  },
    tls: {
    rejectUnauthorized: false
    }
});

var mailOptions = {
  from: 'jaatdeepam@gmail.com',
  to: 'jaatdeepam@gmail.com',
  subject: 'Sending Email using Node.js',
  text: 'That was easy!'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('mailOption.to  Email sent: ' + info.response);
  }
});