
module.exports = function(socket,io,mysql,dbconfig,app){
var user, userid;
var id;
var alpha = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    var connection = mysql.createConnection(dbconfig.connection);
    connection.query('USE ' + dbconfig.database);
    io.on('connection',function(socket){
        console.log(socket.id);




        socket.on("basic",function(data){
            user=data.user;
            if(!data.fname.match(alpha)||data.day==""||data.month==""||data.year==""){
                console.log(data);
                io.to(socket.id).emit('error',data);
            }else{
            var dob= data.day+"/"+data.month+"/"+data.year;
                connection.query("SELECT id FROM users WHERE username = ?",[user], function(err, id){
                    if (err)
                        io.to(socket.id).emit('serverError',data);
                    else {
                        userid= id[0].id;
                        connection.query("INSERT into basic (id, username, fname,dob ) values (?,?,?,?) ",[userid,user,data.fname,dob], function(err,row){
                                            if (err)
                                                console.log(err);

                });
            }
        });
            }
        });


        socket.on("fdetails",function(data){
            if(!data.fa.match(alpha)||!data.m.match(alpha)||data.caste==""||data.religion==""){
                console.log(data);
                io.to(socket.id).emit('error',data);
            }else{
                
                connection.query("INSERT into fdetails (id, username,fa,m,religion,caste ) values (?,?,?,?,?,?) ",[userid,user,data.fa,data.m,data.religion,data.caste], function(err,row){
                    if (err)
                        console.log(err);

                });
            }

        });

        socket.on("address",function(data){
            if(data.s==""||data.d==""||data.add1==""||data.add2==""||data.add3==""||data.pin==""){
                            console.log(data);
                            io.to(socket.id).emit('error',data);
                        }else{
                            connection.query("INSERT into address (id, username,s,d,add1,add2,add3,pin ) values (?,?,?,?,?,?,?,?) ",[userid,user,data.s,data.d,data.add1,data.add2,data.add3,data.pin], function(err,row){
                                if (err)
                                    console.log(err);

                            });
                        }

                    });


           socket.on("contact",function(data){
                if(data.email==""||data.contact==""){
                    console.log(data);
                    io.to(socket.id).emit('error',data);
                }else{
                    
                    connection.query("INSERT into contact (id, username,email,contact ) values (?,?,?,?) ",[userid,user,data.email,data.contact], function(err,row){
                        if (err)
                            console.log(err);

                    });
                }
            });


        socket.on("education",function(data){
            if(data.el==""||data.ef==""||data.clg==""){
                console.log(data);
                io.to(socket.id).emit('error',data);
            }else{
                
                connection.query("INSERT into education (id, username,el,ef,clg ) values (?,?,?,?,?) ",[userid,user,data.el,data.ef,data.clg], function(err,row){
                    if (err)
                        console.log(err);

                });
            }

        });

        socket.on("work",function(data){
            if(data.wl==""||data.wi==""||data.wa==""||data.income==""){
                console.log(data);
                io.to(socket.id).emit('error',data);
            }else{
                
                connection.query("INSERT into work (id, username,wl,wi,wa,income ) values (?,?,?,?,?,?) ",[userid,user,data.wl,data.wi,data.wa,data.income], function(err,row){
                    if (err)
                        console.log(err);

                });
                            }

        });

        socket.on("personality",function(data){
            if(data.gen==""||data.body==""||data.height==""||data.ms==""||data.selfd==""){
                console.log(data);
                io.to(socket.id).emit('error',data);
            }else{
                
                connection.query("INSERT into personality (id, username,gen,body,height,ms,selfd ) values (?,?,?,?,?,?,?) ",[userid,user,data.gen,data.body,data.height,data.ms,data.selfd], function(err,row){
                    if (err)
                        console.log(err);

                });
            }
        });




    });

};


