<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title>Welcome to diaryOFlovers</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" /><!-- Custom Theme files -->
	<link href="css/style.css" media="all" rel="stylesheet" type="text/css" /><!-- Custom Theme files --><script src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet" /><!-- Custom Theme files --><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
</head>
<body>
<!-- header-section-starts -->

<div class="container">
<div class="news-paper">
<div class="header">
<div class="header-left">
<div class="logo"><a href="index.html"><img src="images/logo2.png" /></a>
</div>
</div>
</div>
<br />
<br />
<br /><hr>
<div class="menu-strip">
<ul>
	<li><b><a href="ml.html">mY Life</a></b></li>
	<li><b><a href="entry.php">Entry</a></b></li>
	<li><b><a href="pe.php">Previous Entries</a></b></li>
</ul>
</div>
			<!-- script for menu -->
				<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			<!-- script for menu -->
			<div class="clearfix"></div>
	<center>
			<div class="main-content">		
<?php
 if(isset($_POST['submit']))
{
	$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
	date_default_timezone_set("Asia/Kolkata");
	

	

	$token=rand(100000,999999);
	
	$image1 = $_FILES['image1']['name'];
	$state = $_POST['state'];
	$district = $_POST['district'];
	$village_city = $_POST['village_city'];
	$problem_description = $_POST['problem_description'];
	$entryby = $_POST['entryby'];
   	$date = date('y/m/d');
	$time = date('h:i:s');	
	$dnt = $date."  ".$time;
	
	if($state=="Select State" || empty($entryby)|| empty($problem_description)||empty($village_city)|| $district=="Select District" || empty($image1)){
	$msg="<font color=orange size=+1>Please Complete all the Fields with VALID Inputs</font>";
	}else{
	$rand=rand(1,99999999);
	$image1= sha1($image1.$rand);
	$image1 = $entryby.$image1."_1.jpg";
	$target = "images/my/".$image1;
	move_uploaded_file($_FILES['image1']['tmp_name'], $target);
	$done=mysqli_query($conn, "insert into love_entry (state, district,  village_city, problem_description, dnt, entryby,image1) VALUES('$state', '$district', '$village_city', '$problem_description', '$dnt', '$entryby','$image1') ");
	if($done){
    echo "<font color=#20C900 size=+1>Atempt Sucessful... Please Verify your EMAIL Now!!! </font>";
	    }
		else{
	echo"<font color=orange size=+1>Problem</font>";
	}
}
}
?>
		<form action="" class="problemform" method="post" enctype="multipart/form-data" >
			<select name='state'>
				<option>Select State</option>
				<option>Haryana</option>
				<option>Punjab</option>
				<option>UP</option>
			</select>&nbsp
			<select name='district'>
				<option>Select district</option>
				<option>YNR</option>
				<option>KKR</option>
				<option>KRL</option>
				<option>Kaithal</option>
			</select>&nbsp
			<input type=text name=village_city placeholder="Village/City"><br>
			<textarea name=problem_description placeholder="Picnic Description"></textarea><br>
			<input type=text name=entryby placeholder="Entry By"><br>
			<input type=file name=image1>&nbsp
			<input type=submit name=submit><br>
		</form>	
			</div>	
				<div class="clearfix"></div>
	</center>
			<div class="footer text-center">
<div class="bottom-menu">
<ul>
	<li><b><a href="index.html">My Life</a></b></li>
	<li>|</li>
	<li><b><a href="entry.php">Entry</a></b></li>
	<li>|</li>
	<li><b><a href="pe.php">Pervious Entries</a></b></li>
</ul>
				
</div>

<div class="copyright text-center">
<p><b>The 'Diary of Lovers' is Co Powered by <a href="dhandag.tech">DHANDAg</a><sup>&copy; </sup></b></p>
</div>
</div>
<b> </b></div>
</div>
</body>
</html>