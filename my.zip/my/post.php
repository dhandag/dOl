<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title>Welcome to diaryOFlovers</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" /><!-- Custom Theme files -->
	<link href="css/style.css" media="all" rel="stylesheet" type="text/css" /><!-- Custom Theme files --><script src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet" /><!-- Custom Theme files --><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
</head>
<body>
<!-- header-section-starts -->

<div class="container">
<div class="news-paper">
<div class="header">
<div class="header-left">
<div class="logo"><a href="index.html"><img src="images/logo2.png" /></a>
</div>
</div>
</div>
<br />
<br />
<br /><hr>
<span class="menu"><center>Menu</center></span>
<div class="menu-strip">
<ul>
	<li><b><a href="ml.html">mY Life</a></b></li>
	<li><b><a href="entry.php">Entry</a></b></li>
	<li><b><a href="pe.php">Previous Entries</a></b></li>
</ul>
</div>
			<!-- script for menu -->
				<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			<!-- script for menu -->
			<div class="clearfix"></div>
	<center>
			<div class="main-content">
			    <?php 
		$image1 = $_GET['id'];
	if(empty($image1)){
		header("Location: posts.php");
	}else{
	$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
	$query = @mysqli_query($conn, "select * from love_entry where image1='$image1'");
	$get= @mysqli_fetch_assoc($query);
	$state = $get['state'];
	$district = $get['district'];
	$village_city = $get['village_city'];
	$problem_description = $get['problem_description'];
	$submiting_date = $get['dnt'];
	$entryby = $get['entryby'];
	
	echo "<form name=post class=post> 
	<font color=#20C900 size=+1>State</font>: ".$state."&nbsp&nbsp&nbsp&nbsp
	<font color=#20C900 size=+1>District</font>: ".$district."&nbsp&nbsp&nbsp&nbsp 
	<font color=#20C900 size=+1>Village/City</font>: ".$village_city."<br>
	<font color=orange size=+1>Picnic Description</font>: ".$problem_description."<br>
	<font color=orange size=+1>Submiting Date</font>: ".$submiting_date."<br> 
	<font color=orange size=+1>EnrtyBy</font>: ". $entryby."<br>
	<font color=orange size=+1>Provided Images</font>:<img src=images/my/$image1 align=bottom>";}?>
</div>
				<div class="clearfix"></div>
	</center>
			<div class="footer text-center">
<div class="bottom-menu">
<ul>
	<li><b><a href="ml.html">My Life</a></b></li>
	<li>|</li>
	<li><b><a href="entry.html">Entry</a></b></li>
	<li>|</li>
	<li><b><a href="pe.html">Pervious Entries</a></b></li>
</ul>
				
</div>

<div class="copyright text-center">
<p><b>The 'Diary of Lovers' is Co Powered by <a href="dhandag.tech">DHANDAg</a><sup>&copy; </sup></b></p>
</div>
</div>
<b> </b></div>
</div>
</body>
</html>