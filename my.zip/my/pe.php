<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title>Welcome to diaryOFlovers</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" /><!-- Custom Theme files -->
	<link href="css/style.css" media="all" rel="stylesheet" type="text/css" /><!-- Custom Theme files --><script src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet" /><!-- Custom Theme files --><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
</head>
<body>
<!-- header-section-starts -->

<div class="container">
<div class="news-paper">
<div class="header">
<div class="header-left">
<div class="logo"><a href="index.html"><img src="images/logo2.png" /></a>
</div>
</div>
</div>
<br />
<br />
<br /><hr>
<div class="menu-strip">
<ul>
	<li><b><a href="ml.html">mY Life</a></b></li>
	<li><b><a href="entry.php">Entry</a></b></li>
	<li><b><a href="pe.php">Previous Entries</a></b></li>
</ul>
</div>
			<!-- script for menu -->
			<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			
			
	<!-- script for menu -->
			<div class="clearfix"></div>
	<center>
<!--	    <div class=sort>Sort by:
			    <select name="forma" onchange="location = this.value;" align=right>
			        <option value="pe.php?s=mv">Mostly Visited</option>
			        <option value="pe.php?s=lv">Less Visited</option>
			        <option value="pe.php?s=ea">Entry By (A-Z)</option>
			        <option value="pe.php?s=ez">Entry By (Z-A)</option>
			        <option value="pe.php?s=n">New</option>
			        <option value="pe.php?s=o">Old</option>
			    </select>
			</div>    -->
			<div class="main-content">
			    
			 <!--   
			    <?php
	$s = $_GET['s'];

if($s=="o"){
	$uquery="SELECT image1 FROM love_entry ORDER BY `submiting_date` ASC";
} else if($s=="lv"){
	$uquery="SELECT image1 FROM love_entry ORDER BY `views` ASC";
} else if($s=="ea"){
	$uquery="SELECT image1 FROM love_entry ORDER BY `entryby` ASC";
} else if($s=="ez"){
	$uquery="SELECT image1 FROM love_entry ORDER BY `entryby` DESC";
} else if($s=="n"){
    echo "sadf";
	$uquery="SELECT image1 FROM love_entry ORDER BY `submiting_date` DESC";
} else {
	$uquery="SELECT image1 FROM love_entry ORDER BY `views` DESC";
} ?>  -->

<?php
	$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
		$uquery="SELECT image1 FROM love_entry";
	$query_pro=$conn->multi_query($uquery);
	if($query_pro){
				    echo"<ol class=posts>";
		$result=$conn->store_result();
		
				while($row=$result->fetch_assoc()){
					foreach($row as $image1){
					$query = mysqli_query($conn,"select * from love_entry where `image1`='$image1'");
                	$get =mysqli_fetch_assoc($query);
                	$entryby=$get['entryby'];
                	echo "<li><a href=post.php?id=".$image1."><image height=50 src=images/my/".$image1."></a><br>@".$entryby;
				}
				}
			}	
?>
			    
			    
			</div>	
				<div class="clearfix"></div>
	</center>
			<div class="footer text-center">
<div class="bottom-menu">
<ul>
	<li><b><a href="index.html">My Life</a></b></li>
	<li>|</li>
	<li><b><a href="entry.php">Entry</a></b></li>
	<li>|</li>
	<li><b><a href="pe.php">Pervious Entries</a></b></li>
</ul>
				
</div>

<div class="copyright text-center">
<p><b>The 'Diary of Lovers' is Co Powered by <a href="dhandag.tech">DHANDAg</a><sup>&copy; </sup></b></p>
</div>
</div>
<b> </b></div>
</div>
</body>
</html>