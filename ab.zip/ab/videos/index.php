<!DOCTYPE html>
<html>
<head>
<title>Our Videos</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="../js/jquery.min.js"></script>
<script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5ac225c11fff98001395ab50&product=sticky-share-buttons"></script>
<script type="text/javascript" src="../js/jquery.leanModal.min.js"></script>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->

</head>
<body>

<?php
$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
	$query = @mysqli_query($conn, "select * from problem WHERE `a`= '1' ");
	$get= @mysqli_fetch_assoc($query);
	$b=$get['b'];
	mysqli_query($conn, ("UPDATE problem SET `b`=$b+1 WHERE `a`='1'"));
?>

	<!-- header-section-starts -->
	<div class="container">	
		<div class="news-paper">
			<div class="header">
				<div class="header-left">
					<div class="logo">
						<a href="../index.html">
							<img src="../images/logo2.png"></a>
					<div class="search">
						<form action="../posts/search.php?.value">
							<input type="text" name="findt" value="" placeholder="Finding Anything"/>
							<input type="submit" value="">
						</form>
					</div>
					</div>
					</div>
					
				</div>
				</div><b><br><br><br>
			<span class="menu"></span>
			<div class="menu-strip">
				<ul>           
					<li><a href="../about.html">About</a></li>
					<li><a href="">Videos</a></li>
					<li><a href="../posts/problem_entry.php">Problem Entry</a></li>
					<li><a href="../posts/">Posts</a></li>
					<li><a href="../contact_us.html">Contact Us</a></li>
				</ul>
			</div>
			<!-- script for menu -->
				<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			<!-- script for menu -->
			<div class="clearfix"></div>
	<center>
			<div class="main-content">
			    
<?php
	$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
	$uquery="SELECT image1 FROM problem_entry";
	
	$query_pro=$conn->multi_query($uquery);
	if($query_pro){
				    echo"<ol class=posts>";
		$result=$conn->store_result();
				while($row=$result->fetch_assoc()){
					foreach($row as $image1){
					    
                	$query = mysqli_query($conn,"select * from problem_entry where `image1`='$image1'");
                	$get =mysqli_fetch_assoc($query);
                	$entryby=$get['entryby'];
                	$video=$get['video'];
                	if(!empty($video)){
                	echo "<li><a href=../posts/post.php?id=".$image1."><image height=50 src=thum/".$image1."></a>@".$entryby;
						
                	}
				}}
			}	
?>
			    
			    
			</div>
		</div>	
				<div class="clearfix"></div>
	</center>
			<div class="footer text-center">
				<div class="bottom-menu">
					<ul>           
					<li><a href="../about.html">About</a></li> | 
					<li><a href="../videos/">Videos</a></li> | 
					<li><a href="../posts/problen_entery/">Problem Entry</a></li> | 
					<li><a href="../posts/">Posts</a></li> | 
					<li><a href="../contact_us.html">Contact Us</a></li>
				</ul>
				</div>
				<div class="copyright text-center">
					<p>The Voice 4 Nation is Co Powered by <a href=dhandag.tech>DHANDAg</a><sup>&copy </sup></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>