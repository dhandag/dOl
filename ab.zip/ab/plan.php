<html>
<body>
<form name="a" action="dhandag.tech/plan.php">
<input type="text" name="uname">
<input type="text" name="msg">
    <input type="button" name="submit">
</form>
<?php
   $conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
		if(isset($_POST['submit'])){
        $uname= $_POST['uname'];
        $msg=$_POST['msg'];
        $done = mysqli_query($conn,"insert into problem(`a`, `b`)  VALUES('$uname','$msg') ");
        if($done){
        echo("1");
        }else{
        echo(0);
        }
		}
?>
</body>
</html>