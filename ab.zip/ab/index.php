<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title>Welcome to VOICE4NATION</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" /><!-- Custom Theme files -->
	<link href="css/style.css" media="all" rel="stylesheet" type="text/css" /><!-- Custom Theme files --><script src="js/jquery.min.js"></script><script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5ac225c11fff98001395ab50&product=sticky-share-buttons"></script><script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet" /><!-- Custom Theme files --><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
</head>
<body>
<p></p>

<div style="display:none"><embed autostart="true" loop="false" src="sjsa.mp3"></embed></div>
<!-- header-section-starts -->

<div class="container">
<div class="news-paper">
<div class="header">
<div class="header-left">
<div class="logo"><a href="index.html"><img src="images/logo2.png" /></a>

<div class="search">
<form action="posts/search.php/?.value"><input name="findt" placeholder="Finding Anything" type="text" value="" /> <input type="submit" value="" /></form>
</div>
</div>
</div>
</div>
<br />
<br />

<?php
$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
	$query = @mysqli_query($conn, "select * from problem WHERE `a`= '0' ");
	$get= @mysqli_fetch_assoc($query);
	$b=$get['b'];
	mysqli_query($conn, ("UPDATE problem SET `b`=$b+1 WHERE `a`='0'"));
?>
<div class="menu-strip">
<ul>
	<li><b><a href="about.html">About</a></b></li>
	<li><b><a href="videos/">Videos</a></b></li>
	<li><b><a href="posts/problem_entry.php">Problem Entry</a></b></li>
	<li><b><a href="posts/">Posts</a></b></li>
	<li><b><a href="contact_us.html">Contact Us</a></b></li>
</ul>
</div>
<b><!-- script for menu --> <script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script> <!-- script for menu --> </b>

<div class="clearfix"></div>
<b> </b>

<div class="main-content">
<div class="col-md-9 total-news">
<div class="slider">
<h5 class="breaking"><b>Recent Posts.</b></h5>
<b><script src="js/responsiveslides.min.js"></script> <script>
							// You can also use "$(window).load(function() {"
							$(function () {
							  $("#conference-slider").responsiveSlides({
								auto: true,
								manualControls: '#slider3-pager',
							  });
							});
						</script> </b>

<div class="conference-slider"><b><!-- Slideshow 3 --> </b>

<ul class="conference-rslide" id="conference-slider">
	<li><b><img alt="" src="images/c22.jpg" /></b>

	<div class="breaking-news-title">
	<p><b>DEPAMADA </b></p>
	</div>
	</li>
	<li><b><img alt="" src="images/c1.jpg" /></b>
	<div class="breaking-news-title">
	<p><b>DHSADJ</b></p>
	</div>
	</li>
	<li><b><img alt="" src="images/c33.jpg" /></b>
	<div class="breaking-news-title">
	<p><b>CSJJS</b></p>
	</div>
	</li>
	<li><b><img alt="" src="images/c44.jpg" /></b></li>
</ul>
<b> <!-- Slideshow 3 Pager --> </b></div>
<b> </b></div>

<div class="clearfix"></div>
</div>

<div class="clearfix"></div>
</div>
<b> </b>

<div class="footer text-center">
<div class="bottom-menu">
<ul>
	<li><b><a href="about.html">About</a></b></li>
	<li><b>| </b>
    <li><b><a href="videos/">Videos</a></b></li>
	<li><b>| </b>
	<li><b><a href="posts/problem_entry.php">Problem Entry</a></b></li>
	<li><b>| </b>
	<li><b><a href="posts/">Posts</a></b></li>
	<li><b>| </b>
	<li><b><a href="contact_us.html">Contact Us</a></b></li>
</ul>
				
</div>

<div class="copyright text-center">
<p><b>The Voice 4 Nation is Co Powered by <a href="dhandag.tech">DHANDAg</a><sup>&copy; </sup></b></p>
</div>
</div>
<b> </b></div>
</div>
</body>
</html>