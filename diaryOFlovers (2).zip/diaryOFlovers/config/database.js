// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost', // localde iseniz bu , local değilse ip adresini yazınız .
        'user': 'root', // kullanıcı adı 
        'password': '', // şifreniz 
        'database': 'dhandag'// database ismi .
    },
	'database': 'dhandag',
    
};

	
