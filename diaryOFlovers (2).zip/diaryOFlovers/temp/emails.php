
<html>
 <body>
  <form method=post>
    email: <input type=text name=email> 
 
    <select name=pre>
         <option>@hry.nic.in
        <option>.gov.in
        <option>@gmail.com
        <option>.in
    </select>
        <br>
	name: <input type=text name=name><br>
	ref file : <select name=ref>
	    <option>admin-secy-emailIDs.pdf
        <option>Chief Minister's Office - Goverment _ Government of Haryana.pdf
        <option>Contact Us - Ministry of Road Transport & Highways, Government of India.pdf
        <option>Email Contacts - Contacts_ Government of Haryana.pdf
        <option>emailids.pdf
        <option>Governor's Office - Government_ Government of Haryana.pdf
        <option>Haryana_State_Department_Telephone_Directory.pdf
        <option>Ministers - Goverment _ Government of Haryana.pdf
        <option>ministry of rad transport and highway contact detais.pdf
        <option>pibmail.pdf
        <option>Press Information Bureau telephone.pdf
        <option>telephone_rb.pdf
        <option>websites Government of Haryana eProcurement _ Works Tender _ Supplies Tender _ Services Tender_ Live Tender _ Online Tender _ Download Tender _ E-auction _ Live Auction.pdf
        <option>bus emails.png
        <option>civil sectrate.png
    </select><br>
	<input type=submit name=submit>
  </form> 
 </body>
</html>
<?php

if(isset($_POST['submit'])){
	$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");    
     $pre=$_POST['pre'];
 $email=$_POST['email'];
  $name=$_POST['name'];
  $ref_file=$_POST['ref'];
  $email=$email.$pre;
 $done=mysqli_query($conn, "insert into `emails` (`email_add`, `name`, `ref_file`) VALUES('$email','$name','$ref_file') ");
 if($done){
     
  echo $name."<br>".$email."<br>".$ref_file."<br><font color=green>DONE";
 } else 
 {
  echo "<font color=red>Problem";

  }
}
?>