<!DOCTYPE html>
<html>
<head>
<title>Posts Verification</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5ac225c11fff98001395ab50&product=sticky-share-buttons"></script>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->

</head>
<body>
	<!-- header-section-starts -->
	<div class="container">	
		<div class="news-paper">
			<div class="header">
				<div class="header-left">
					<div class="logo">
						<a href="index.html">
							<img src="images/logo2.png"></a>
					<div class="search">
						<form action="posts/search.php?.value">
							<input type="text" name="findt" value="" placeholder="Finding Anything"/>
							<input type="submit" value="">
						</form>
					</div>
					</div>
					
				</div>
				</div><b><br><br><br>
			<span class="menu"></span>
			<div class="menu-strip">
				<ul>           
					<li><a href="about.html">About</a></li>
					<li><a href="videos/">Videos</a></li>
					<li><a href="posts/problem_entry.php">Problem Entry</a></li>
					<li><a href="posts/">Posts</a></li>
					<li><a href="contact_us.html">Contact Us</a></li>
				</ul>
			</div>
			<!-- script for menu -->
				<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			<!-- script for menu -->
			<div class="clearfix"></div>
	<center>
			<div class="main-content">
			    
		<?php
		$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
		$token = $_GET['id'];
	    if(empty($token)){
	    echo "Please verify your Email from MailBox..";
	}else{
	   $uquery = mysqli_query($conn, ("SELECT * FROM problem_entry WHERE `token`='$token'"));
    	$get= @mysqli_fetch_assoc($uquery);
	    $confrim= $get['confrim'];
	    $problem_id= $get['problem_id'];
        $confrim="1";
        $t="";
        if(mysqli_num_rows($uquery)==1){
        if(mysqli_query($conn, ("UPDATE problem_entry SET `confrim`='$confrim', `token`='$t' WHERE problem_id='$problem_id'"))){
		    echo"<font color=#20C900 size=+1>Sucessfully Verified.. We will Contact you Shortly...</font>";
		}else{
		    echo"<font color=orange size=+1>Wrong Token Number or Already Verified!!!</font>";
		}
}else{
		    echo"<font color=orange size=+1>Already Verified!!!</font>";
		}
	}
		?>	    
			    
			    
			    
			</div></div>	
				<div class="clearfix"></div>
	</center>
			<div class="footer text-center">
				<div class="bottom-menu">
					<ul>           
					<li><a href="../about.html">About</a></li> | 
					<li><a href="../Videos/">Videos</a></li> | 
					<li><a href="../Problen_entery/">Problem Entry</a></li> | 
					<li><a href="../Posts/">Posts</a></li> | 
					<li><a href="../contact_us.html">Contact Us</a></li>
				</ul>
				</div>
				<div class="copyright text-center">
					<p>The Voice 4 Nation is Co Powered by <a href=dhandag.tech>DHANDAg</a><sup>&copy </sup></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>