<!DOCTYPE html>
<html>
<head>
<title>Welcome to VOICE4NATION</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="../js/jquery.min.js"></script>
<script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5ac225c11fff98001395ab50&product=sticky-share-buttons"></script>
<script type="text/javascript" src="../js/jquery.leanModal.min.js"></script>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->

</head>
<body>
	<!-- header-section-starts -->
	<div class="container">	
		<div class="news-paper">
			<div class="header">
				<div class="header-left">
					<div class="logo">
						<a href="../index.html">
							<img src="../images/logo2.png"></a>
					<div class="search">
						<form action="search.php?.value">
							<input type="text" name="findt" value="" placeholder="Finding Anything"/>
							<input type="submit" value="">
						</form>
					</div>
					</div>
					
				</div>
				</div><b><br><br><br>
			<span class="menu"></span>
			<div class="menu-strip">
				<ul>           
					<li><a href="../about.html">About</a></li>
					<li><a href="../videos/">Videos</a></li>
					<li><a href="">Problem Entry</a></li>
					<li><a href="index.php">Posts</a></li>
					<li><a href="../contact_us.html">Contact Us</a></li>
				</ul>
			</div>
			<!-- script for menu -->
				<script>
				$( "span.menu" ).click(function() {
				  $( ".menu-strip" ).slideToggle( "slow", function() {
				    // Animation complete.
				  });
				});
			</script>
			<!-- script for menu -->
			<div class="clearfix"></div>
	<center>
			<div class="main-content">		
<?php
 if(isset($_POST['submit']))
{
	$conn= mysqli_connect("localhost","dhandagt_v4n","80531@PApa","dhandagt_v4n") or die("Server Error");
	date_default_timezone_set("Asia/Kolkata");
	

	

	$token=rand(100000,999999);
	
	$image1 = $_FILES['image1']['name'];
	$image2 = $_FILES['image2']['name'];
	$image3 = $_FILES['image3']['name'];
	$state = $_POST['state'];
	$district = $_POST['district'];
	$tehsil = $_POST['tehsil'];
	$village_city = $_POST['village_city'];
	$problem_description = $_POST['problem_description'];
	$entryby = $_POST['entryby'];
   	$mail = $_POST['mail'];
   	$phone= $_POST['phone'];
	$date = date('y/m/d');
	$time = date('h:i:s');	
	$dnt = $date."  ".$time;
	
	if($state=="Select State" || empty($entryby)|| empty($problem_description)|| empty($mail) || empty($phone) ||empty($village_city)|| $tehsil=="Select Tehsil"|| $district=="Select District" || empty($image1)|| empty($image2)|| empty($image3)){
	$msg="<font color=orange size=+1>Please Complete all the Fields with VALID Inputs</font>";
	}else{
	$rand=rand(1,99999999);
	$image1= sha1($image1.$rand);
	$image1 = $enterby.$image1."_1.jpg";
	$target = "images/".$image1;
	move_uploaded_file($_FILES['image1']['tmp_name'], $target);
	$image2 = sha1($image2.$rand);
	$image2 = $enterby.$image2."_2.jpg";
	$target = "images/".$image2;
	move_uploaded_file($_FILES['image2']['tmp_name'], $target);
	$image3= sha1($image3.$rand);
	$image3 = $enterby.$image3."_3.jpg";
	$target = "images/".$image3;
	move_uploaded_file($_FILES['image3']['tmp_name'], $target);

		
	$done=mysqli_query($conn, "insert into problem_entry (mail, token, phone, state, district, tehsil, village_city, problem_description, submiting_date, entryby,image1,image2,image3) VALUES('$mail','$token', '$phone','$state', '$district', '$tehsil', '$village_city', '$problem_description', '$dnt', '$entryby','$image1','$image2','$image3') ");
	if($done){
	    $msg="Thank You for Registrering a Problem with us\n Please verify your email by Click on below link \n http://DHANDAg.tech/token.php?id=".$token."...";
	    if(mail($mail,"V4N: Verification Code",$msg,"DHANDAg<dhandag@info.tech>")){
    echo "<font color=#20C900 size=+1>Atempt Sucessful... Please Verify your EMAIL Now!!! </font>";
	    }
	}else{
	echo"<font color=orange size=+1>Problem</font>";
	}
}
}
?>
		<form action="" class="problemform" method="post" enctype="multipart/form-data" >
			<select name='state'>
				<option>Select State</option>
				<option>Haryana1</option>
				<option>Haryana2</option>
				<option>Haryana3</option>
			</select>&nbsp
			<select name='district'>
				<option>Select district</option>
				<option>YNR</option>
				<option>KKR</option>
				<option>KRL</option>
			</select>&nbsp
			<select name='tehsil'>
				<option>Select tehsil</option>
				<option>RADAUR</option>
				<option>JAG</option>
				<option>CHAH</option>
			</select><br>
			<input type=text name=village_city placeholder="Village/City"><br>
			<textarea name=problem_description placeholder="Problem Description"></textarea><br>
			<input type=text name=entryby placeholder="Entry By"><br>
			<input type=text name=mail placeholder="Enter a valid EMAIL Address for verification">
			<input type=text name=phone placeholder="Enter a valid PHONE No. for verification"><br>
			<input type=file name=image1>&nbsp
			<input type=file name=image2>&nbsp
			<input type=file name=image3><br>
			<input type=submit name=submit><br>
		</form>	
			</div>	
				<div class="clearfix"></div>
	</center>
			<div class="footer text-center">
				<div class="bottom-menu">
					<ul>  
					<li><a href="../about.html">About</a></li> | 
					<li><a href="../videos/">Videos</a></li> | 
					<li><a href="problen_entery.php">Problem Entry</a></li> | 
					<li><a href="index.php">Posts</a></li> | 
					<li><a href="../contact_us.html">Contact Us</a></li>
				</ul>
				</div>
				<div class="copyright text-center">
					<p>The Voice 4 Nation is Co Powered by <a href=dhandag.tech>DHANDAg</a><sup>&copy </sup></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>